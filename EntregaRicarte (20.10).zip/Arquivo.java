/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package locadora;

import java.io.FileWriter;
import java.io.File;
import java.io.IOException;
import java.io.BufferedWriter;
import java.util.Scanner;

/**
 *
 * @author bacs3
 */
public class Arquivo {
    
    public Arquivo(){
    }
    
    public static void criaArquivo() throws IOException {
	//String arq = "";
	FileWriter arquivo;
        try {
            arquivo = new FileWriter(new File("ArquivoLocadora.txt"));
            //arquivo.write(arq);
            arquivo.close();
        }
        
        catch (IOException e) {   
        }         
        catch (Exception e) {
        }
    }
    
    public static void escritor(String path) throws IOException {
        try (BufferedWriter buffWrite = new BufferedWriter(new FileWriter(path)))
        {
            String linha = "";
            Scanner in = new Scanner(System.in);
            System.out.println("Escreva algo: ");
            linha = in.nextLine();
            buffWrite.append(linha + "\n");
        }
    }
    
}
