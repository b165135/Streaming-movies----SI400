/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package locadora;

/**
 *
 * @author bacs3
 */
public class Cliente extends Pessoa {
    
    private int pontosAdquiridos;
    private Aluguel alugado; 

    public Cliente(int pontosAdquiridos, Aluguel alugado, String nome, int rg, String dataNascimento, int cpf, String endereco, int telefone) {
        super(nome, rg, dataNascimento, cpf, endereco, telefone);
        this.pontosAdquiridos = pontosAdquiridos;
        this.alugado = alugado;
    }
    
    

    public Aluguel getAlugado() {
        return alugado;
    }

    public void setAlugado(Aluguel alugado) {
        this.alugado = alugado;
    }
   
    public int getPontosAdquiridos() {
        return pontosAdquiridos;
    }

    public void setPontosAdquiridos(int pontosAdquiridos) {
        this.pontosAdquiridos = pontosAdquiridos;
    }
    
    public int calculaPontosAdquiridos () {
        /*Caso o aluguel que o cliente realize seja por apenas um dia, ele ganha 1 ponto;
          Caso seja de 2 a 5 dias, ele ganha 2 pontos;
          Caso seja de 6 ou 7 dias, ele ganha 3 pontos;
        */
        
        pontosAdquiridos = 0;
        
        if (alugado.getDiasAlugado() == 1) {
            pontosAdquiridos = pontosAdquiridos + 1;
        }
        
        if ((alugado.getDiasAlugado() >= 2) && (alugado.getDiasAlugado() <=5)) {
            pontosAdquiridos = pontosAdquiridos + 2;
        }
        
        if (alugado.getDiasAlugado() >= 6) {
            pontosAdquiridos = pontosAdquiridos + 3;
        }
        
        return pontosAdquiridos;
            
    }
}
