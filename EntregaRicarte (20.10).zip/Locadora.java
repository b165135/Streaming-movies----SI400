/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package locadora;

import java.io.IOException;

/**
 *
 * @author bacs3
 */
public class Locadora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        NomeFilme f1;
        f1 = new NomeFilme ("Velozes e furiosos", "Velozes e furiosos 8", 18, 2000,"Filme de carros","Ação", 90);
        
        TipoFilme t1;
        t1 = new TipoFilme ("Filme Regular");
        
        Filme filme1;
        filme1 = new Filme (f1,t1);
        
        Aluguel a1;
        a1 = new Aluguel (3, filme1);
        
        Cliente c1;
        c1 = new Cliente (0, a1, "Bruno",53639068, "18/08/1995", 4255273, "Rua X", 34265714);
        
        Funcionario func1;
        func1 = new Funcionario (1234,"func1","senha1",0,a1,"Arnaldo", 45678, "19/08/1995", 65235, "Rua Y", 34265713);
        
        Compra compra1;
        compra1 = new Compra ("Bruno", "Velozes e furiosos", "Compra de filme regular");
        
        String path = "ArquivoLocadora.txt";
        
        Arquivo.escritor(path);
    }
    
}
