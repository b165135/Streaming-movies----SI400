/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package locadora;

/**
 *
 * @author bacs3
 */
public class Pessoa {
    private String nome;
    private int rg;
    private String dataNascimento;
    private int cpf;
    private String endereco;
    private int telefone;
    

    public Pessoa(String nome, int rg, String dataNascimento, int cpf, String endereco, int telefone) {
        this.nome = nome;
        this.rg = rg;
        this.dataNascimento = dataNascimento;
        this.cpf = cpf;
        this.endereco = endereco;
        this.telefone = telefone;
    }
    
    
    public int calculaPontosAdquiridos () {
        return 0;
    }
    
    

    public int getRg() {
        return rg;
    }

    public void setRg(int rg) {
        this.rg = rg;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
     public void mudaEndereco (String novoEndereco) {
        this.endereco = novoEndereco; 
    }
    
    public void mudaTelefone (int novoTelefone) {
        this.telefone = novoTelefone; 
    }
    
}
