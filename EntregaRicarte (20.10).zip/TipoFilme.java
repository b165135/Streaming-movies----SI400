/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package locadora;

/**
 *
 * @author bacs3
 */
public class TipoFilme {
    private String tipoDoFilme;

    public String getTipoDoFilme() {
        return tipoDoFilme;
    }

    public void setTipoDoFilme(String tipoDoFilme) {
        this.tipoDoFilme = tipoDoFilme;
    }

    public TipoFilme(String tipoDoFilme) {
        this.tipoDoFilme = tipoDoFilme;
    }
    
    public void alteraTipoFilme (String novoTipoFilme) {
        this.tipoDoFilme = novoTipoFilme; 
    }
}
