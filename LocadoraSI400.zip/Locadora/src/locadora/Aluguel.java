package locadora;

/**
 * Classe que contabiliza o número de dias que um determinado filme foi alugado.
 * @author Otavio e Bruno
 */
public class Aluguel {
    private int diasAlugado;
    private Filme filme;
    
    /**
     * Construtor da classe
     * @param diasAlugado
     * @param filme 
     */
    public Aluguel(int diasAlugado, Filme filme){
            this.diasAlugado = diasAlugado;
            this.filme = filme;
    }
   
    /**
     * 
     * @return diasalugado
     */
    public int getDiasAlugado() {
        return diasAlugado;
    }
    
    /**
     * 
     * @param diasAlugado 
     */
    public void setDiasAlugado(int diasAlugado) {
        this.diasAlugado = diasAlugado; 
    }
    
    /**
     * 
     * @return filme
     */
    public Filme getFilme() {
        return filme;
    }
    
    /**
     * 
     * @param filme 
     */
    public void setFilme(Filme filme) {
        this.filme = filme;
    }
}

