package locadora;

import java.io.FileWriter;
import java.io.File;
import java.io.IOException;
import java.io.BufferedWriter;
import java.util.Scanner;

/**
 * Classe que cria um arquivo.txt no diretório do projeto e salva o nome dos
 * clientes que acumularam pontos
 * 
 * @author Otavio e Bruno
 */
public class Arquivo {

    public Arquivo(){
    }
     /**
      * Método que gera arquivo.txt na pasta
      * @throws IOException 
      */
    public static void criaArquivo() throws IOException {
	String arq = "Pontos adquiridos por clientes: /n";
	
        try {
            FileWriter arquivo = new FileWriter(new File("ClientPoints.txt"));
            arquivo.write(arq);
            arquivo.close();
        }
        
        catch (IOException e) {   
        }         
        catch (Exception e) {
        }
    }
    
    /**
     * Método que escreve nome dos clientes que acumularam pontos no arquivo
     * criado por "criaArquivo"
     * 
     * @param path
     * @throws IOException 
     */
    public static void escritor(String path) throws IOException {
        try (BufferedWriter buffWrite = new BufferedWriter(new FileWriter(path)))
        {
            String linha = "";
            Scanner in = new Scanner(System.in);
            System.out.println("Insira o nome do cliente: ");
            linha = in.nextLine();
            buffWrite.append(linha + "\n");
        }
    }
}
