package locadora;

import java.io.Serializable;
/**
 * Classe que representa os objetos do tipo "Cliente" e extende a classe 
 * "Pessoa"
 * 
 * @author Bruno e Otavio
 */
public class Cliente extends Pessoa implements Serializable{
    private int pontosAdquiridos;
    private Aluguel alugado; 

    /**
     * 
     * @param pontosAdquiridos
     * @param alugado
     * @param nome
     * @param rg
     * @param dataNascimento
     * @param cpf
     * @param endereco
     * @param telefone 
     */
    public Cliente(int pontosAdquiridos, Aluguel alugado, String nome, int rg, String dataNascimento, int cpf, String endereco, int telefone) {
        super(nome, rg, dataNascimento, cpf, endereco, telefone);
        this.pontosAdquiridos = pontosAdquiridos;
        this.alugado = alugado;
    }
    
    /**
     * 
     * @return alugado
     */
    public Aluguel getAlugado() {
        return alugado;
    }
    
    /**
     * 
     * @param alugado 
     */
    public void setAlugado(Aluguel alugado) {
        this.alugado = alugado;
    }
   
    /**
     * 
     * @return pontosAdquiridos
     */
    public int getPontosAdquiridos() {
        return pontosAdquiridos;
    }
    
    /**
     * 
     * @param pontosAdquiridos 
     */
    public void setPontosAdquiridos(int pontosAdquiridos) {
        this.pontosAdquiridos = pontosAdquiridos;
    }
    /**
     * Método que calcula quantos pontos o cliente acumulou de acordo com o
     * número de dias que alugou um filme
     * 
     * @return Pontos adquiridos pelo cliente
     */
    @Override
    public int calculaPontosAdquiridos () {
        /*Caso o aluguel que o cliente realize seja por apenas um dia, ele ganha 1 ponto;
          Caso seja de 2 a 5 dias, ele ganha 2 pontos;
          Caso seja de 6 ou 7 dias, ele ganha 3 pontos;
        */
        
        pontosAdquiridos = 0;
        
        if (alugado.getDiasAlugado() == 1) {
            pontosAdquiridos = pontosAdquiridos + 1;
        }
        
        if ((alugado.getDiasAlugado() >= 2) && (alugado.getDiasAlugado() <=5)) {
            pontosAdquiridos = pontosAdquiridos + 2;
        }
        
        if (alugado.getDiasAlugado() >= 6) {
            pontosAdquiridos = pontosAdquiridos + 3;
        }
        
        return pontosAdquiridos;   
    }
}
