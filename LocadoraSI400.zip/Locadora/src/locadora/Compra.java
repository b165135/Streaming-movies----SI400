package locadora;

/**
 * Classe que representa objetos do tipo "compra" e armazena os dados de uma
 * cpmpra feita por algum cliente
 * @author Bruno e Otavio
 */
public class Compra {
    private String nomeCliente;
    private String nomeFilme;
    private String tipoCompra;

    /**
     * 
     * @return nomecliente
     */
    public String getNomeCliente() {
        return nomeCliente;
    }
    
    /**
     * 
     * @param nomeCliente 
     */
    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    /**
     * 
     * @return nomeFilme
     */
    public String getNomeFilme() {
        return nomeFilme;
    }
    /**
     * 
     * @param nomeFilme 
     */
    public void setNomeFilme(String nomeFilme) {
        this.nomeFilme = nomeFilme;
    }

    /**
     * 
     * @return tipoCompra
     */
    public String getTipoCompra() {
        return tipoCompra;
    }
    
    /**
     * 
     * @param tipoCompra 
     */
    public void setTipoCompra(String tipoCompra) {
        this.tipoCompra = tipoCompra;
    }
    
    /**
     * Construtor da classe
     * @param nomeCliente
     * @param nomeFilme
     * @param tipoCompra 
     */
    public Compra(String nomeCliente, String nomeFilme, String tipoCompra) {
        this.nomeCliente = nomeCliente;
        this.nomeFilme = nomeFilme;
        this.tipoCompra = tipoCompra;
    }
}
