package locadora;

/**
 * Classe que representa objetos do tipo "filme" e contém 
 * @author Otavio e Bruno
 */
public class Filme {
    private NomeFilme nomeFilme;
    private TipoFilme tipoFilme;

    /**
     * 
     * @return nomeFilme
     */
    public NomeFilme getNomeFilme() {
        return nomeFilme;
    }

    /**
     * 
     * @param nomeFilme 
     */
    public void setNomeFilme(NomeFilme nomeFilme) {
        this.nomeFilme = nomeFilme;
    }

    /**
     * 
     * @return tipoFilme
     */
    public TipoFilme getTipoFilme() {
        return tipoFilme;
    }

    /**
     * 
     * @param tipoFilme 
     */
    public void setTipoFilme(TipoFilme tipoFilme) {
        this.tipoFilme = tipoFilme;
    }

    /**
     * Construtor da classe. Obtém objetos das classes "NomeFilme" e "TipoFilme"
     * @param nomeFilme
     * @param tipoFilme 
     */
    public Filme(NomeFilme nomeFilme, TipoFilme tipoFilme) {
        this.nomeFilme = nomeFilme;
        this.tipoFilme = tipoFilme;
    }
}
