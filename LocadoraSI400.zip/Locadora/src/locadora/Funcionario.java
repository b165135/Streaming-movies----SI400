package locadora;

import java.io.Serializable;
/**
 * Classe que representa os objetos do tipo "Funcionario" e extende
 * a classe "Pessoa"
 * 
 * @author bacs3
 */
public class Funcionario extends Pessoa implements Serializable {
    private int carteiraDeTrabalho;
    private String login;
    private String senha;
    private int pontosAdquiridos; 
    private Aluguel filmeAlugado;

    /**
     * Construtor da classe
     * @param carteiraDeTrabalho
     * @param login
     * @param senha
     * @param pontosAdquiridos
     * @param filmeAlugado
     * @param nome
     * @param rg
     * @param dataNascimento
     * @param cpf
     * @param endereco
     * @param telefone 
     */
    public Funcionario(int carteiraDeTrabalho, String login, String senha, int pontosAdquiridos, Aluguel filmeAlugado, String nome, int rg, String dataNascimento, int cpf, String endereco, int telefone) {
        super(nome, rg, dataNascimento, cpf, endereco, telefone);
        this.carteiraDeTrabalho = carteiraDeTrabalho;
        this.login = login;
        this.senha = senha;
        this.pontosAdquiridos = pontosAdquiridos;
        this.filmeAlugado = filmeAlugado;
    }
    
    /**
     * 
     * @return filmealugado
     */
    public Aluguel getFilmeAlugado() {
        return filmeAlugado;
    }

    /**
     * 
     * @param filmeAlugado 
     */
    public void setFilmeAlugado(Aluguel filmeAlugado) {
        this.filmeAlugado = filmeAlugado;
    }
    
    /**
     * 
     * @return pontosAdquiridos
     */
    public int getPontosAdquiridos() {
        return pontosAdquiridos;
    }

    /**
     * 
     * @param pontosAdquiridos 
     */
    public void setPontosAdquiridos(int pontosAdquiridos) {
        this.pontosAdquiridos = pontosAdquiridos;
    }
    
    /**
     * 
     * @return carteiraDeTrabalho
     */
    public int getCarteiraDeTrabalho() {
        return carteiraDeTrabalho;
    }

    /**
     * 
     * @param carteiraDeTrabalho 
     */
    public void setCarteiraDeTrabalho(int carteiraDeTrabalho) {
        this.carteiraDeTrabalho = carteiraDeTrabalho;
    }

    /**
     * 
     * @return login
     */
    public String getLogin() {
        return login;
    }

    /**
     * 
     * @param login 
     */
    public void setLogin(String login) {
        this.login = login;
    }

    /**
     * 
     * @return senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * 
     * @param senha 
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    /**
     * Método que calcula quantos pontos o cliente acumulou de acordo com o
     * número de dias que alugou um filme
     * 
     * @return Pontos adquiridos pelo cliente
     */
    @Override
    public int calculaPontosAdquiridos () {
        /*Caso o aluguel que o funcionário consiga seja de 1 a 2 dias, ele não ganha pontos;
          Caso seja de 3 a 6 dias, ele ganha 1 ponto;
          Caso seja de 7 dias, ele ganha 2 pontos;
        */
        
        pontosAdquiridos = 0;
        
        if ((filmeAlugado.getDiasAlugado() >=1) && (filmeAlugado.getDiasAlugado() <=2))  {
            pontosAdquiridos = pontosAdquiridos;
        }
        
        if ((filmeAlugado.getDiasAlugado() >= 3) && (filmeAlugado.getDiasAlugado() <=6)) {
            pontosAdquiridos = pontosAdquiridos + 1;
        }
        
        if (filmeAlugado.getDiasAlugado() >= 7) {
            pontosAdquiridos = pontosAdquiridos + 2;
        }
        
        return pontosAdquiridos;
            
    }
}
