package locadora;

/**
 * Classe que representa objetos do tipo "NomeFilme" e contém todas as informações
 * do filme alugado
 * @author Bruno e Otavio
 */
public class NomeFilme {
    private String nome;
    private String titulo;
    private int classificacao;
    private int anolancamento;
    private String sinopse;
    private String genero;
    private float duracao;

    /**
     * 
     * @return nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * 
     * @param nome 
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * 
     * @return titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * 
     * @param titulo 
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * 
     * @return classificacao
     */
    public int getClassificacao() {
        return classificacao;
    }

    /**
     * 
     * @param classificacao 
     */
    public void setClassificacao(int classificacao) {
        this.classificacao = classificacao;
    }

    /**
     * 
     * @return enolancamento
     */
    public int getAnolancamento() {
        return anolancamento;
    }

    /**
     * 
     * @param anolancamento 
     */
    public void setAnolancamento(int anolancamento) {
        this.anolancamento = anolancamento;
    }

    /**
     * 
     * @return sinopse
     */
    public String getSinopse() {
        return sinopse;
    }

    /***
     * 
     * @param sinopse 
     */
    public void setSinopse(String sinopse) {
        this.sinopse = sinopse;
    }

    /**
     * 
     * @return genero
     */
    public String getGenero() {
        return genero;
    }

    /**
     * 
     * @param genero 
     */
    public void setGenero(String genero) {
        this.genero = genero;
    }

    /**
     * 
     * @return duracao
     */
    public float getDuracao() {
        return duracao;
    }

    /**
     * 
     * @param duracao 
     */
    public void setDuracao(float duracao) {
        this.duracao = duracao;
    }
    
    /**
     * Construtor da cllasse
     * @param nome
     * @param titulo
     * @param classificacao
     * @param anolancamento
     * @param sinopse
     * @param genero
     * @param duracao 
     */
    public NomeFilme(String nome, String titulo, int classificacao, int anolancamento, String sinopse, String genero, float duracao) {
        this.nome = nome;
        this.titulo = titulo;
        this.classificacao = classificacao;
        this.anolancamento = anolancamento;
        this.sinopse = sinopse;
        this.genero = genero;
        this.duracao = duracao;
    }
    
    /**
     * Este método atualiza a classificação indicativa do filme 
     * @param novaClassificacao 
     */
    public void atualizaClassificacao (int novaClassificacao) {
        this.classificacao = novaClassificacao;
    }
    
}
