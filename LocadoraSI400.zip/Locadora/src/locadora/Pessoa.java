package locadora;

/**
 * Superclasse das classes "Cliente" e "Funcionario", contém apenas informações
 * utilizadas das duas subclasses
 * 
 * @author Otavio
 */
public class Pessoa {
    private String nome;
    private int rg;
    private String dataNascimento;
    private int cpf;
    private String endereco;
    private int telefone;
    
    /**
     * Construtor da classe
     * @param nome
     * @param rg
     * @param dataNascimento
     * @param cpf
     * @param endereco
     * @param telefone 
     */
    public Pessoa(String nome, int rg, String dataNascimento, int cpf, String endereco, int telefone) {
        this.nome = nome;
        this.rg = rg;
        this.dataNascimento = dataNascimento;
        this.cpf = cpf;
        this.endereco = endereco;
        this.telefone = telefone;
    }
    
    /**
     * 
     * @return rg
     */
    public int getRg() {
        return rg;
    }

    /**
     * 
     * @param rg 
     */
    public void setRg(int rg) {
        this.rg = rg;
    }

    /**
     * 
     * @return dataNascimento
     */
    public String getDataNascimento() {
        return dataNascimento;
    }

    /**
     * 
     * @param dataNascimento 
     */
    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    /**
     * 
     * @return cpf
     */
    public int getCpf() {
        return cpf;
    }

    /**
     * 
     * @param cpf 
     */
    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    /**
     * 
     * @return endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * 
     * @param endereco 
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    /**
     * 
     * @return telefone
     */
    public int getTelefone() {
        return telefone;
    }

    /**
     * 
     * @param telefone 
     */
    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }
    
    /**
     * 
     * @return nome 
     */
    public String getNome() {
        return nome;
    }

    /**
     * 
     * @param nome 
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    /**
     * Este método atualiza o endereço da pessoa (Cliente/Funcionario)
     * @param novoEndereco 
     */
     public void mudaEndereco (String novoEndereco) {
        this.endereco = novoEndereco; 
    }
     
     /**
      * Este método atualiza o telefone da pessoa (Cliente/Funcionario)
      * @param novoTelefone 
      */
    public void mudaTelefone (int novoTelefone) {
        this.telefone = novoTelefone; 
    }
    
    /**
     * Este método para realização do polimorfismo contido nas classes Cliente
     * e Funcionario
     * @return 0
     */
    public int calculaPontosAdquiridos(){
        return 0;
    }
}
