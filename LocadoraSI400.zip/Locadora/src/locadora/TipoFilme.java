package locadora;

/**
 * Classe que representa objetos do tipo "TipoFilme" e contém o tipo de gênero
 * do filme, como: Lançamento, Infantil, etc.
 * @author Otavio e Bruno
 */
public class TipoFilme {
  private String tipoDoFilme;

   /**
   * 
   * @return tipoDoFilme
   */
    public String getTipoDoFilme() {
        return tipoDoFilme;
    }

    /**
     * 
     * @param tipoDoFilme 
     */
    public void setTipoDoFilme(String tipoDoFilme) {
        this.tipoDoFilme = tipoDoFilme;
    }

    /**
     * 
     * @param tipoDoFilme tipoDoFilme
     */
    public TipoFilme(String tipoDoFilme) {
        this.tipoDoFilme = tipoDoFilme;
    }
    
    /**
     * 
     * @param novoTipoFilme 
     */
    public void alteraTipoFilme (String novoTipoFilme) {
        this.tipoDoFilme = novoTipoFilme; 
    }
}
