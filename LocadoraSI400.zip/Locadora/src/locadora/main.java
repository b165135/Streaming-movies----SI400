package locadora;

import java.io.IOException;
import view.home;

/**
 * Classe principal do projeto
 * @author Otavio e Bruno
 */
public class main {
    public static void main(String[] args) throws IOException {
        new home().setVisible(true); //Chama o método da view para iniciar a interface
    }
}
